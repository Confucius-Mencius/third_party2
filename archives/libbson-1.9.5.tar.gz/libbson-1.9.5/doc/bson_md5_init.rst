:man_page: bson_md5_init

bson_md5_init()
===============

Synopsis
--------

.. code-block:: c

  void
  bson_md5_init (bson_md5_t *pms);

Parameters
----------

* ``pms``: A :symbol:`bson_md5_t`.

Description
-----------

Initialize a new instance of the MD5 algorithm.

