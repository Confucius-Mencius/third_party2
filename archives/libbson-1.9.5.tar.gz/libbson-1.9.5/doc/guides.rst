:man_page: bson_guides

Guides
======

.. toctree::
  :titlesonly:

  streaming-bson
  json
