#include <sys/param.h>
#include <dev/systrace.h>

#include <stdlib.h>

int
main(void)
{

	return(0);
}
