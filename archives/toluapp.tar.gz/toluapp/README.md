# tolua++ for Lua 5.2/5.3

This is a patched version of tolua++ for Lua 5.2 and 5.3. Earlier versions of Lua are not supported.

The 'master' branch has been converted to CMake. The 'lua52' branch contains the same core changes with the original SCons build system intact.

**WARNING**

The patch might be incomplete at this time. Use at your own risk!
