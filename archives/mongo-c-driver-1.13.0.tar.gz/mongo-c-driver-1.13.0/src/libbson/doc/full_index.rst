:man_page: bson_reference
:orphan:

.. Yes it's confusing: the home page is called "index" so this is "full_index",
   and it works by including the complete Table of Contents from the homepage,
   i.e., "index".

Index
=====

.. toctree::
  :maxdepth: 6
  :titlesonly:

  index
