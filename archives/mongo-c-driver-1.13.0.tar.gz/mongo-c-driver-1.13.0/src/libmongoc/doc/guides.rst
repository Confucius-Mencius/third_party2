:man_page: mongoc_guides

Guides
======

.. toctree::
   :titlesonly:
   :maxdepth: 1

   mongoc-common-task-examples
   advanced-connections
   connection-pooling
   cursors
   bulk
   aggregate
   distinct-mapreduce
   visual-studio-guide
   create-indexes
   debugging
